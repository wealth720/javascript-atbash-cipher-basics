function atbashCipher(text) {
  let result = '';
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const code = text.charCodeAt(i);

    if (char >= 'A' && char <= 'Z') {
      result += String.fromCharCode(155 - code); // A ↔ Z
    } else if (char >= 'a' && char <= 'z') {
      result += String.fromCharCode(219 - code); // a ↔ z
    } else {
      result += char; // Keep non-letters as-is
    }
  }
  return result;
}

function runAtbash(action) {
  const input = document.getElementById("inputText").value;
  const output = atbashCipher(input); // same logic for encode/decode
  const label = action === "encode" ? "Encoded" : "Decoded";
  document.getElementById("outputText").textContent = `${label}: ${output}`;
}
